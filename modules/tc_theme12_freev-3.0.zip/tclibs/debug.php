
<?php 
if ($this->countModules('debug'))  
$tcParams .= '<div id="tc_debug"><jdoc:include type="modules" name="debug" style="none"  /></div>';
?>
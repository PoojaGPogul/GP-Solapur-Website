DROP TABLE IF EXISTS `#__simplephotogallery_images`;
DROP TABLE IF EXISTS `#__simplephotogallery_settings`;
DROP TABLE IF EXISTS `#__simplephotogallery_album`;
